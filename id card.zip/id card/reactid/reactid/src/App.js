import React, { useState } from "react";
import html2canvas from 'html2canvas';


import './App.css';


function App() {
  const [name, setName] = useState("");
  const [dob, setDob] = useState("");
  const [course, setCourse] = useState("");
  const [year, setYear] = useState("");
  const [rollNumber, setRollNumber] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [image, setImage] = useState(null);
  const handleImageUpload = (event) => {
    setImage(event.target.files[0]);
  }
  const [downloadUrl, setDownloadUrl] = useState();
  const handleDownload = () => {
    html2canvas(document.querySelector(".container"), { useCORS: true }).then(canvas => {
      setDownloadUrl(canvas.toDataURL());
    });
  };
  return (
    <div className="back">
      <form>
        <h3>Please fill-in the form</h3>
        <label>Full Name</label>
        <input
          type="text"
          maxLength="24"
          placeholder="Your name"
          value={name}
          onChange={(event) => setName(event.target.value)}
        />
        <label>Date of birth</label>
        <input
          type="date"
          placeholder="Date of birth"
          value={dob}
          onChange={(event) => setDob(event.target.value)}
        />
        <label>Course</label>
        <input
          type="text"
          placeholder="course"
          value={course}
          onChange={(event) => setCourse(event.target.value)}
        />
        <label>Year</label>
        <input
          type="text"
          placeholder="Year"
          value={year}
          onChange={(event) => setYear(event.target.value)}
        />
        <label>Roll Number</label>
        <input
          type="text"
          placeholder="Roll Number"
          value={rollNumber}
          onChange={(event) => setRollNumber(event.target.value)}
        />
        <label>Phone Number</label>
        <input
          type="number"
          placeholder="phone number"
          value={phoneNumber}
          onChange={(event) => setPhoneNumber(event.target.value)}
        />
        <label htmlFor="file" className="upload">
          Upload an Image
        </label>
        <br />
        <span>Choose one that desrcibes you perfectly</span>
        <input
          type="file"
          id="file"
          accept="image/*"
          onChange={handleImageUpload}
        />
      </form>
      <div className="container">
        <header id="head">
          <div className="camp">
            <h4>Special Coding Batch</h4>
            <span>Korangi,Kakinada</span>
          </div>
          <img src="scb.png" id="logo" alt=" " />
        </header>

        <div className="content">
          <div>
             {image && <img src={URL.createObjectURL(image)} alt=" " />}
          </div>
          {/* {<img src={Image} id="imgDisplayed" /> } */}
          <ul>
            <li id="name">{name}</li>
            <li id="birth">{dob}</li>
            <li id="course">{course}</li>
            <li id="year">{year}</li>
            <li id="rollNumber">{rollNumber}</li>
            <li id="phoneNumber">{phoneNumber}</li>
          </ul>
          
        </div>
        
      </div>
      <div class="down">
          <a href={downloadUrl} download="IDCard.png">
               <button onClick={handleDownload}>Download</button>
          </a>
      </div>
    </div>

  );
}



export default App;

