import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ReferenceNotesForm from './ReferenceNotes';
import SaveData from './SaveData';


function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<ReferenceNotesForm />} />
        <Route path="/saved-data" element={<SaveData />} />
      </Routes>
    </BrowserRouter>
  );
}
export default App;