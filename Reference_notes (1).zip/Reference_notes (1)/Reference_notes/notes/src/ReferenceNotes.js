import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './ReferenceNotes.css';

function ReferenceNotesForm() {
  const [title, setTitle] = useState('');
  const [url, setUrl] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const response = await fetch('http://localhost:2500/referencenotes', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          Title: title,
          URL: url,
        }),
      });
      if (!response.ok) {
        throw new Error('Something went wrong while saving the data');
      }
      navigate(`/saved-data?title=${title}&url=${url}`);
    } catch (error) {
      console.error(error);
      alert(error.message);
    }
  };

  return (
    <>
      <form onSubmit={handleSubmit}>
        <div className='reference-form-container'>
          <label className='reference-form'>
            <h3>TITLE :</h3>
            <input type='text' placeholder='Enter the title' value={title} onChange={(event) => setTitle(event.target.value)} />
          </label>
          <br />
          <label className='reference-form'>
            <h3>URL :</h3>
            <input type='url' placeholder='Url' value={url} onChange={(event) => setUrl(event.target.value)} />
          </label>
          <br />
          <button className='reference-form-save' type='submit'>
            Save
          </button>
        </div>
      </form>
    </>
  );
}

export default ReferenceNotesForm;
