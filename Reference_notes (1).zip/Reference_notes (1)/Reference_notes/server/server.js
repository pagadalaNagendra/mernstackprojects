const express = require("express");
const mongoose = require("mongoose");
const jwt=require('jsonwebtoken');
const middleware=require('./middleware');
const cors=require('cors');
const referencenote = require("./referencenotes");

mongoose.set('strictQuery', false);
const app = express();

mongoose.connect(
  "mongodb://127.0.0.1:27017/coordinator_dashboard",
 {
    useNewUrlParser:true,
    useUnifiedTopology:true,
     
 }).then(
    ()=>console.log("DB connected")
 )


app.use(express.json())
app.use(cors({origin:'*'}))


app.get("/", (req, res) => {
  return res.send("<h1>COORDINATOR DASHBOARD</h1>");
});

app.post('/referencenotes', async (req, res) => {
    try {
      const { Title, URL } = req.body;
      const newreferencenote = await referencenote.create({
        Title,URL
      });
      return res.status(201).json(newreferencenote);
    } catch (err) {
      console.error(err);
      return res.status(500).send('Server Error');
    }
  });
  app.get('/referencenotes', async (req, res) => {
    try {
      const referencenotes = await referencenote.find();
      return res.status(200).json(referencenotes);
    } catch (err) {
      console.error(err); 
      return res.status(500).send('Server Error');
    }
  });
  app.put('/referencenotes/:id', async (req, res) => {
    try {
      const {Title, URL} = req.body;
      const existingreferencenote = await referencenote.findByIdAndUpdate(
        req.params.id,
        {Title, URL },
        { new: true }
      );
      if (!existingreferencenote) {
        return res.status(404).send('Notes not found');
      }
      return res.status(200).json(existingreferencenote);
    } catch (err) {
      console.error(err);
      return res.status(500).send('Server Error');
    }
  });
  app.delete('/referencenotes/:id', async (req, res) => {
    try {
      const existingreferencenote = await referencenote.findByIdAndDelete(
        req.params.id
      );
      if (!existingreferencenote) {
        return res.status(404).send('Notes not found');
      }
      return res.status(200).send('Notes deleted successfully');
    } catch (err) {
      console.error(err);
      return res.status(500).send('Server Error');
    }
  });
  
  app.listen(2500, () => {
    console.log("Server is running....");
  }); 