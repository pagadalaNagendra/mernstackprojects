const mongoose = require('mongoose')
const referencenote = new mongoose.Schema({
    Title : {                 
        type : String,
        required : true
    },
    URL: {
        type : String,
        required : true
    }
})

module.exports=mongoose.model('referencenote',referencenote)