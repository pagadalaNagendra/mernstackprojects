import { useLocation } from "react-router-dom";
import { useState } from "react";
import "./AttendanceSummary.css";

const AttendanceSummary = () => {
  const { state } = useLocation();
  const { attendance, date } = state;
  const students = Object.keys(attendance);
  const [searchTerm, setSearchTerm] = useState("");

  const totalPresent = students.filter(
    (student) => attendance[student] === "Present"
  ).length;

  const totalAbsent = students.filter(
    (student) => attendance[student] === "Absent"
  ).length;

  const formattedDate = new Date(date).toLocaleDateString("en-GB");

  const filteredStudents = students.filter((student) =>
    student.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const downloadAttendance = () => {
    const csvContent =
      "data:text/csv;charset=utf-8," +
      "Student Name,Attendance\n" +
      Object.keys(attendance)
        .map((student) => `${student},${attendance[student]}`)
        .join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Attendance_${formattedDate}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="attendance-summary-container">
      <h1 className="attendance-summary-header">Attendance Summary</h1>
      <h4 className="attendance-summary-header"> {formattedDate}</h4>
      <div className="attendance-form-student">
        <input
          type="text"
          placeholder="Search student"
          value={searchTerm}
          onChange={(event) => setSearchTerm(event.target.value)}
        />
      </div>
      <ul className="attendance-summary-list">
        {filteredStudents.map((student, index) => (
          <li key={index}>
            {student}: {attendance[student]}
          </li>
        ))}
      </ul>
      <div className="attendance-summary-totals">
        <h3>
          <div className="attendance-summary-present">
            Total Present: {totalPresent}
          </div>
        </h3>
        <h3>
          <div className="attendance-summary-absent">
            Total Absent: {totalAbsent}
          </div>
        </h3>
      </div>
      <button className="attendance-form-button" onClick={downloadAttendance}>Download Attendance</button>
    </div>
  );
};

export default AttendanceSummary;