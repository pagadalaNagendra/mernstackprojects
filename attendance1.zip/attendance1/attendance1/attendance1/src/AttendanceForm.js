import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./AttendanceForm.css";

const AttendanceForm = () => {
  const navigate = useNavigate();

  const [totalPresent, setTotalPresent] = useState(0);
  const [totalAbsent, setTotalAbsent] = useState(0);
  const [newStudent, setNewStudent] = useState("");
  const [students, setStudents] = useState([
    "Bhanu Prabhas",
    "Hemanth Kumar",
    "Ajay",
    "Vishnu",
    "Satya",
    "Nagendra",
    "Divya",
    "Prasanna",
    "Chandini",
    "keerthi"
  ]);
  const [attendance, setAttendance] = useState(
    students.reduce((obj, student) => ({ ...obj, [student]: "Absent" }), {})
  );

  const [day, setDay] = useState("");
  const [month, setMonth] = useState("");
  const [year, setYear] = useState("");

  const handleButtonClick = (student, status) => {
    setAttendance({ ...attendance, [student]: status });

    if (status === "Present") {
      setTotalPresent(totalPresent + 1);
    } else {
      setTotalAbsent(totalAbsent + 1);
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
  
    // Check if the entered date is valid
    const newDate = new Date(`${month} ${day}, ${year}`);
    if (isNaN(newDate.getTime())) {
      window.alert("Please enter a valid date");
      return;
    }
  
    // Proceed with submitting the form
    navigate("/summary", { state: { attendance, date: newDate.toLocaleString() } });
  };
  

  const handleNewStudentChange = (event) => {
    setNewStudent(event.target.value);
  };

  const handleAddStudent = () => {
    if (newStudent.trim() !== "") {
      setStudents([...students, newStudent]);
      setAttendance({ ...attendance, [newStudent]: "Absent" });
      setNewStudent("");
    } else {
      window.alert("Please enter a valid student name");
    }
  };

  return (
    <div className="attendance-form-container">
      <form onSubmit={handleSubmit}>
        <h1 className="attendance-form-header">Attendance Form</h1>
        <div className="attendance-form-Date">
          <input type="number" min="1" max="31" placeholder="DD" value={day} onChange={(e) => setDay(e.target.value)} />
          <input type="text" placeholder="MM" value={month} onChange={(e) => setMonth(e.target.value)} />
          <input type="number" min="2000" max="2100" placeholder="YYYY" value={year} onChange={(e) => setYear(e.target.value)} />
        </div>
        {students.map((student, index) => (
          <div className="attendance-form-student" key={index}>
            <span>{student}</span>
            <div className="attendance-form-button-container">
              <button
                type="button"
                className={`attendance-form-button ${
                  attendance[student] === "Present" ? "active" : ""
                }`}
                onClick={() => handleButtonClick(student, "Present")}
              >
                Present
              </button>
              <button
                type="button"
                className={`attendance-form-button ${
                  attendance[student] === "Absent" ? "active" : ""
                }`}
                onClick={() => handleButtonClick(student, "Absent")}
              >
                Absent
              </button></div>
      </div>
    ))}
    <div className="attendance-form-student">
      <input type="text" placeholder="Add new student" value={newStudent} onChange={handleNewStudentChange} />
      <button type="button" onClick={handleAddStudent}>
        Add
      </button>
    </div>
    <button type="submit" className="attendance-form-submit">
      Submit
    </button>
  </form>
</div>
);
};

export default AttendanceForm;
                
                
                