import { BrowserRouter, Routes, Route } from "react-router-dom";
import AttendanceForm from "./AttendanceForm";
import AttendanceSummary from "./AttendanceSummary";

const App = () => {
return (
<BrowserRouter>
<Routes>
<Route path="/" element={<AttendanceForm />} />
<Route path="/summary" element={<AttendanceSummary />} />
</Routes>
</BrowserRouter>
);
};

export default App;
