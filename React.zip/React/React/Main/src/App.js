import React from 'react';
import Header from './navbar';
import Card from './Card';
import ItemListPage from './editpage/ItemListPage';
// import MainContent from './components/MainContent';
// import Footer from './components/Footer';
import './App.css';

function App() {
  return (
    <div>
    <div className="App">
      <Header />
      {/* <MainContent />
      <Footer /> */}
    </div>
    <div className="container">
    {/* <div style={{ padding: '80px 0 0 0' }}>
     <Navbar />
    </div> */}
    <Card class="front" title="Student Info" link="editpage" />
    <Card class="front1" title="Performance" link="#" />
    <Card class="front4" title="Schedule" link="#" />
    <Card class="front5" title="Code Compiler" link="#" />
    <Card class="front9" title="Todo" link="#" />
    <Card class="front6" title="Projects" link="#" />
    <Card class="front2" title="Attendance" link="http://localhost:3002/" />
    <Card class="front3" title="Team Info" link="#" />
    <Card class="front7" title="Announcements" link="#" />
    <Card class="front8" title="Cources" link="#" />
    <Card class="front10" title="Id card" link="#" />
    <Card class="front11" title="Settings" link="#" />
  </div>
  </div>

  );
}

export default App;








// import React from 'react';
// import TeamCards from './Card';
// import Navbar from './navbar'


// function App() {
//   return (
//     <div style={{ padding: '80px 0 0 0' }}>
//       <Navbar />
//       <TeamCards />
//     </div>
//   );
// }

// export default App;
