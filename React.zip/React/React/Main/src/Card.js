import React from 'react';
import './style.css';

function Card(props) {
  return (
  <a href={props.link}>
    <div className="card">
      <div className={`front ${props.class}`}></div>
      <div className="back">
      {props.title}
      </div>
    </div>
    </a>
  );
}

export default Card;

// import React from 'react';

// function Card({ frontText, backText }) {
//   return (
//     <div className="card">
//       <div className="front">{frontText}</div>
//       <div className="back">
//         <a href="#">{backText}</a> 
//       </div>
//     </div>
//   );
// }

// export default Card;



// import React from 'react';
// import './style.css';
// import VanillaTilt from 'vanilla-tilt';

// class Main extends React.Component {
//   componentDidMount() {
//     VanillaTilt.init(document.querySelectorAll(".card"), {
//       max: 15,
//       speed: 400,
//       glare: true,
//       "max-glare": 1,
//     });
//   }

//   render() {
//     return (
//       <div className="container" style={{ paddingTop: '100px' }}>
//         <div className="card">
//           <div className="content">
//             <h2>01</h2>
//             <a href="#">Student Info</a>
//           </div>
//         </div>
//         <div className="card">
//           <div className="content">
//             <h2>02</h2>
//             <a href="#">Attendance</a>
//           </div>
//         </div>
//         <div className="card">
//           <div className="content">
//             <h2>03</h2>
//             <a href="#">Performance</a>
//           </div>
//         </div>
//         <div className="card">
//           <div className="content">
//             <h2>04</h2>
//             <a href="#">Schedule</a>
//           </div>
//         </div>
//         <div className="card">
//           <div className="content">
//             <h2>05</h2>
//             <a href="#">Code Compiler</a>
//           </div>
//         </div>
//         <div className="card">
//           <div className="content">
//             <h2>06</h2>
//             <a href="#">Team info</a>
//           </div>
//         </div>
//         <div className="card">
//           <div className="content">
//             <h2>07</h2>
//             <a href="#">Reference Note</a>
//           </div>
//         </div>
//         <div className="card">
//           <div className="content">
//             <h2>08</h2>
//             <a href="#">Announcements</a>
//           </div>
//         </div>
//         <div className="card">
//           <div className="content">
//             <h2>09</h2>
//             <a href="#">Cources</a>
//           </div>
//         </div>
//         <div className="card">
//           <div className="content">
//             <h2>10</h2>
//             <a href="#">Projects</a>
//           </div>
//         </div>
//         <div className="card">
//           <div className="content">
//             <h2>11</h2>
//             <a href="#">Id Card</a>
//           </div>
//         </div>
//         <div className="card">
//           <div className="content">
//             <h2>09</h2>
//             <a href="#">Settings</a>
//           </div>
//         </div>
//       </div>
//     );
//   }
// }

// export default Main;
