import React, { useState } from 'react';

function ItemListPage() {
  const [items, setItems] = useState([
    { id: 1, name: "Item 1" },
    { id: 2, name: "Item 2" },
    { id: 3, name: "Item 3" }
  ]);

  const [editingItemId, setEditingItemId] = useState(null);
  const [newItemName, setNewItemName] = useState("");

  const handleCreateItem = () => {
    const newItem = {
      id: Math.random(),
      name: newItemName
    };

    setItems([...items, newItem]);
    setNewItemName("");
  };

  const handleEditItem = (itemId) => {
    setEditingItemId(itemId);
  };

  const handleSaveItem = (itemId) => {
    const updatedItems = items.map(item => {
      if (item.id === itemId) {
        return { ...item, name: newItemName };
      }
      return item;
    });

    setItems(updatedItems);
    setEditingItemId(null);
    setNewItemName("");
  };

  const handleDeleteItem = (itemId) => {
    const updatedItems = items.filter(item => item.id !== itemId);

    setItems(updatedItems);
  };

  return (
    <div>
      <h1>Item List</h1>
      <ul>
        {items.map(item => (
          <li key={item.id}>
            {editingItemId === item.id ? (
              <>
                <input type="text" value={newItemName} onChange={(e) => setNewItemName(e.target.value)} />
                <button onClick={() => handleSaveItem(item.id)}>Save</button>
              </>
            ) : (
              <>
                {item.name}
                <button onClick={() => handleEditItem(item.id)}>Edit</button>
              </>
            )}
            <button onClick={() => handleDeleteItem(item.id)}>Delete</button>
          </li>
        ))}
      </ul>
      <input type="text" value={newItemName} onChange={(e) => setNewItemName(e.target.value)} />
      <button onClick={handleCreateItem}>Create</button>
    </div>
  );
}

export default ItemListPage;