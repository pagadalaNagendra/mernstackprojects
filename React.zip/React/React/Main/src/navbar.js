import React from 'react';
// import './App.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBell, faUser } from '@fortawesome/free-solid-svg-icons';
import logo from './scb_logo.png'

function App() {
  return (
    <div>
      <header>
        <nav>
          <ul>
            <li style={{ float: 'left' }}><img id="logo" src={logo} alt="scb-logo" /></li>
            <li><a href="#"><FontAwesomeIcon icon={faBell} /></a></li>
            <li><a href="#"><FontAwesomeIcon icon={faUser} /></a></li>
          </ul>
        </nav>
      </header>
    </div>
  );
}

export default App;
