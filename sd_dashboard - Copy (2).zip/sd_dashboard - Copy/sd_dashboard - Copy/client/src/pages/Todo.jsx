import React from "react";
import Sidenav from "../components/Sidenav";
import Navbar from "../components/Navbar"
import Box from "@mui/material/Box";
import Tabletodo from "../components/Tabletodo";


export default function Todo() {
  return (
    <>
    <div className="bgcolor">
    <Navbar />
    <Box height={70} />
      <Box sx={{ display: "flex" }}>
        <Sidenav />
        <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
          <h1>Todo</h1>
          <Tabletodo />
        </Box>
      </Box>

    </div>
    
    </>
  );
}