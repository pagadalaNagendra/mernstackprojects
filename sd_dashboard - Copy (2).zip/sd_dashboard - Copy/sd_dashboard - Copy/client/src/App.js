import React from 'react';
import {Routes, Route, BrowserRouter} from "react-router-dom";
import Home from "./pages/Home"
import Personal from "./pages/Personal";
import Schedule from "./pages/Schedule";
import Technical from "./pages/Technical"
import Todo from './pages/Todo';
import Settings from './pages/Settings';


export default function App() {
  return( 
  <>
   <BrowserRouter>
    <Routes>
      <Route path="/" exact element={<Home />}></Route>
      <Route path="/personal" exact element={<Personal />}></Route>
      <Route path="/technical" exact element={<Technical />}></Route>
      <Route path="/schedule" exact element={<Schedule />}></Route>
      <Route path="/todo" exact element={<Todo />}></Route>
      <Route path="/settings" exact element={<Settings />}></Route>
    </Routes>
   </BrowserRouter>
  </>
  )
}
